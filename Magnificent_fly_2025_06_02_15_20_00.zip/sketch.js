function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let jogador;
let comida = [];
let pontuacao = 0;
let obstaculos = [];
let gameState = "jogando";

function setup() {
    createCanvas(400, 400);
    jogador = new Jogador();
    criarComidaInicial(5);
    criarObstaculos(3);
}

function draw() {
    if (gameState === "jogando") {
        background(200, 220, 240);
        noStroke();

        jogador.mover();
        jogador.mostrar();

        for (let i = comida.length - 1; i >= 0; i--) {
            comida[i].mostrar();
            if (jogador.pegar(comida[i])) {
                comida.splice(i, 1);
                criarComida();
                pontuacao += comida[i].pontos;
            }
        }

        for (let i = obstaculos.length - 1; i >= 0; i--) {
            obstaculos[i].mostrar();
            obstaculos[i].mover();
            if (jogador.colidir(obstaculos[i])) {
                gameState = "gameOver";
            }
        }

        textSize(24);
        fill(50);
        textAlign(LEFT, TOP);
        text("Pontuação: " + pontuacao, 20, 20);
    } else if (gameState === "gameOver") {
        background(150);
        textSize(32);
        fill(0);
        textAlign(CENTER);
        text("Game Over!", width / 2, height / 2 - 30);
        textSize(24);
        text("Pontuação Final: " + pontuacao, width / 2, height / 2 + 10);
        textSize(20);
        text("Pressione ESPAÇO para reiniciar", width / 2, height / 2 + 50);
    }
}

function keyPressed() {
    if (gameState === "jogando") {
        if (keyCode === UP_ARROW) {
            jogador.velY = -5;
        } else if (keyCode === DOWN_ARROW) {
            jogador.velY = 5;
        } else if (keyCode === LEFT_ARROW) {
            jogador.velX = -5;
        } else if (keyCode === RIGHT_ARROW) {
            jogador.velX = 5;
        }
    } else if (gameState === "gameOver") {
        if (keyCode === 32) {
            reiniciarJogo();
        }
    }
}

function keyReleased() {
    if (gameState === "jogando") {
        jogador.velX = 0;
        jogador.velY = 0;
    }
}

function criarComida() {
    let x = random(width);
    let y = random(height);
    comida.push(new Comida(x, y));
}

function criarComidaInicial(numComida) {
    for (let i = 0; i < numComida; i++) {
        let x = random(width);
        let y = random(height);
        comida.push(new Comida(x, y));
    }
}

function criarObstaculos(numObstaculos) {
    for (let i = 0; i < numObstaculos; i++) {
        let x = random(width);
        let y = random(height);
        obstaculos.push(new Obstaculo(x, y));
    }
}

function reiniciarJogo() {
    jogador = new Jogador();
    comida = [];
    pontuacao = 0;
    obstaculos = [];
    criarComidaInicial(5);
    criarObstaculos(3);
    gameState = "jogando";
}

class Jogador {
    constructor() {
        this.x = width / 2;
        this.y = height / 2;
        this.tamanho = 30; // Tamanho do emoji
        this.velX = 0;
        this.velY = 0;
        this.emoji = '😊'; // Emoji do jogador
    }

    mostrar() {
        textSize(this.tamanho);
        textAlign(CENTER, CENTER);
        text(this.emoji, this.x, this.y);
    }

    mover() {
        this.x += this.velX;
        this.y += this.velY;

        this.x = constrain(this.x, this.tamanho / 2, width - this.tamanho / 2);
        this.y = constrain(this.y, this.tamanho / 2, height - this.tamanho / 2);
    }

    pegar(outro) {
        let d = dist(this.x, this.y, outro.x, outro.y);
        // Ajusta a distância para a colisão com emojis (aproximado)
        if (d < this.tamanho / 2 + outro.tamanho / 2) {
            return true;
        } else {
            return false;
        }
    }

    colidir(obstaculo) {
        let d = dist(this.x, this.y, obstaculo.x, obstaculo.y);
        // Ajusta a distância para a colisão com emojis (aproximado)
        if (d < this.tamanho / 2 + obstaculo.tamanho / 2) {
            return true;
        } else {
            return false;
        }
    }
}

class Comida {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.tamanho = 25; // Tamanho do emoji da comida
        this.emoji = '🍎'; // Emoji da comida
        this.pontos = 1;
    }

    mostrar() {
        textSize(this.tamanho);
        textAlign(CENTER, CENTER);
        text(this.emoji, this.x, this.y);
    }
}

class Obstaculo {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.tamanho = 30; // Tamanho do emoji do obstáculo
        this.emoji = '💣'; // Emoji do obstáculo
        this.velocidadeX = random(-2, 2);
        this.velocidadeY = random(-2, 2);
    }

    mostrar() {
        textSize(this.tamanho);
        textAlign(CENTER, CENTER);
        text(this.emoji, this.x, this.y);
    }

    mover() {
        this.x += this.velocidadeX;
        this.y += this.velocidadeY;

        if (this.x + this.tamanho / 2 > width || this.x - this.tamanho / 2 < 0) {
            this.velocidadeX *= -1;
        }
        if (this.y + this.tamanho / 2 > height || this.y - this.tamanho / 2 < 0) {
            this.velocidadeY *= -1;
        }
    }
}